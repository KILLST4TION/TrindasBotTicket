require("dotenv").config();
const { Client, GatewayIntentBits, SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

client.once("ready", () => {
    console.log(`✅ Bot online como ${client.user.tag}`);
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === "anunciar") {
        if (!interaction.member.permissions.has("ManageMessages")) {
            return interaction.reply({ content: "❌ Você não tem permissão para usar este comando!", ephemeral: true });
        }

        const titulo = interaction.options.getString("titulo");
        const descricao = interaction.options.getString("descricao");
        const cor = interaction.options.getString("cor") || "#00ff00";
        const imagem = interaction.options.getString("imagem");

        const embed = new EmbedBuilder()
            .setTitle(titulo)
            .setDescription(descricao)
            .setColor(cor)
            .setTimestamp();

        if (imagem) {
            embed.setImage(imagem);
        }

        await interaction.reply({ embeds: [embed] });
    }

    if (interaction.commandName === "limpar") {
        if (!interaction.member.permissions.has("ManageMessages")) {
            return interaction.reply({ content: "❌ Você não tem permissão para usar este comando!", ephemeral: true });
        }

        const quantidade = interaction.options.getInteger("quantidade");
        if (quantidade < 1 || quantidade > 100) {
            return interaction.reply({ content: "❌ Você deve escolher um número entre 1 e 100!", ephemeral: true });
        }

        const messages = await interaction.channel.bulkDelete(quantidade, true);
        await interaction.reply({ content: `✅ ${messages.size} mensagens apagadas!`, ephemeral: true });
    }
});

client.login(process.env.TOKEN);

////// Bot trinda By Bispo7/////////////////